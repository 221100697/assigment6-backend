<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yomna Refaat Abdelbadea</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
        }
        .container {
            max-width: 600px;
        }
        img {
            width: 200px;
            border-radius: 10px;
            display: block;
        }
        h1 {
            color: purple;
        }
        a {
            color: blue;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .contact-form input, .contact-form textarea {
            display: block;
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
        }
        .contact-form button {
            background-color: purple;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Display User Image -->
        <img src="<?php echo isset($_SESSION["image"]) ? $_SESSION["image"] : 'default.jpg'; ?>" alt="User Image">

        <!-- Display User Info -->
        <h1><?php echo isset($_SESSION["name"]) ? $_SESSION["name"] : "Your Name"; ?></h1>
        <p>
            <a href="mailto:<?php echo isset($_SESSION["email"]) ? $_SESSION["email"] : "your.email@example.com"; ?>">
                <?php echo isset($_SESSION["email"]) ? $_SESSION["email"] : "your.email@example.com"; ?>
            </a>
        </p>
        <h2>Job Title: <?php echo isset($_SESSION["job_title"]) ? $_SESSION["job_title"] : "Your Job Title"; ?></h2>

        <h3>Submit Your Information</h3>
        <form class="contact-form" action="upload.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="image" required>
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="job_title" placeholder="Your Job Title" required>
            <button type="submit" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
