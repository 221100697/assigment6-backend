<?php
session_start();

if (isset($_POST["submit"]) && isset($_FILES["image"])) {
    // Define upload directory
    $uploadDir = "uploads/";
    
    // Ensure the uploads directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Get file details
    $fileName = basename($_FILES["image"]["name"]);
    $uploadFile = $uploadDir . $fileName;

    // Move uploaded file to uploads folder
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadFile)) {
        $_SESSION["image"] = $uploadFile;
    } else {
        $_SESSION["image"] = "default.jpg"; // Default image if upload fails
    }

    // Store user input in session
    $_SESSION["name"] = $_POST["name"];
    $_SESSION["email"] = $_POST["email"];
    $_SESSION["job_title"] = $_POST["job_title"];
}

// Redirect back to index.php
header("Location: index.php");
exit();
